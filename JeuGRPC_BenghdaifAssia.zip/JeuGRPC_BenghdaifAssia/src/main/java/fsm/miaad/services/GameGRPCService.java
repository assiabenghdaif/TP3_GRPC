package fsm.miaad.services;

import fsm.miaad.stubs.Game;
import fsm.miaad.stubs.GameServiceGrpc;
import io.grpc.stub.StreamObserver;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;


public class GameGRPCService extends GameServiceGrpc.GameServiceImplBase {


    @Override
    public StreamObserver<Game.GameCurrencyRequest> gameBiDirectionalStreaming(StreamObserver<Game.GameCurrencyResponse> responseObserver) {
        return new StreamObserver<Game.GameCurrencyRequest>() {
            Random random = new Random();

            // generate a random integer between 1 and 1000
            int number_win = random.nextInt(1000) + 1;
            @Override
            public void onNext(Game.GameCurrencyRequest gameCurrencyRequest) {

                int number_send=gameCurrencyRequest.getNumber();
                String result="";
                if(number_send==number_win) {
                    result = "BRAVO vous avez gagné";
                    Game.GameCurrencyResponse response=Game.GameCurrencyResponse.newBuilder()
                            .setResponse(result+" "+number_win)
                            .build();
                    responseObserver.onNext(response);
                    responseObserver.onCompleted();
                }
                else if (number_send<number_win) {
                    result = "Votre nombre est plus petit";
                    Game.GameCurrencyResponse response=Game.GameCurrencyResponse.newBuilder()
                            .setResponse(result+" "+number_win)
                            .build();
                    responseObserver.onNext(response);
                }
                else {
                    result = "Votre nombre est plus grand";
                    Game.GameCurrencyResponse response=Game.GameCurrencyResponse.newBuilder()
                            .setResponse(result+" "+number_win)
                            .build();
                    responseObserver.onNext(response);
                }






            }

            @Override
            public void onError(Throwable throwable) {

            }

            @Override
            public void onCompleted() {
                responseObserver.onCompleted();

            }
        };
    }

}
